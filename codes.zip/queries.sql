SELECT fname, lname, STRING_AGG(allergic_product, ', ') AS allergies FROM client_allergies --show all allergies of clients as 1 row
INNER JOIN client ON client.clientid=client_allergies.clientid
INNER JOIN allergies ON allergies.allergyid=client_allergies.allergyid
GROUP BY fname, lname;
---------------------------------------------------------------------------------------------------------------------------
SELECT DISTINCT(UNNEST(STRING_TO_ARRAY(name, ', '))) FROM products; --shows all products separately
---------------------------------------------------------------------------------------------------------------------------
UPDATE goal  SET daily_calorie_intake = CASE
WHEN gender='Female' THEN --for females
CASE 
WHEN goal_weight<current_weight --if the goal is to lose weight
THEN CASE
When activity_level = 'Low' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.2 - 500, -2) --formulas for different activity levels
When activity_level = 'Medium' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.375 - 500, -2)
When activity_level = 'High' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.55 - 500, -2)
end
When goal_weight>current_weight --if the goal is to gain weight
THEN CASE
When activity_level = 'Low' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.2 + 500, -2)
When activity_level = 'Medium' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.375 + 500, -2)
When activity_level = 'High' THEN round((10*current_weight + 6.25*height - 5*age - 161)*1.55 + 500, -2)
end
end
WHEN gender='Male' THEN --same thing for males, the difference is in numbers
CASE 
WHEN goal_weight<current_weight
THEN CASE
When activity_level = 'Low' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.2 - 500, -2)
When activity_level = 'Medium' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.375 - 500, -2)
When activity_level = 'High' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.55 - 500, -2)
end
When goal_weight>current_weight 
THEN CASE
When activity_level = 'Low' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.2 + 500, -2)
When activity_level = 'Medium' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.375 + 500, -2)
When activity_level = 'High' THEN round((10*current_weight + 6.25*height - 5*age - 5)*1.55 + 500, -2)
end
end
END
FROM client_info, progress WHERE goal.clientid=client_info.clientid and progress.clientid=goal.clientid;
-----------------------------------------------------------------------------------------------------------------------
UPDATE products --deleting allergic products for each person from the list of products
SET name = REPLACE(name, allergic_product, '') 
FROM diet_plan_products, diet_plan, client_allergies, allergies 
WHERE diet_plan_products.productid=products.productid 
AND diet_plan.diet_planid=diet_plan_products.diet_planid 
AND client_allergies.clientid=diet_plan.clientid 
AND allergies.allergyid=client_allergies.allergyid;
-----------------------------------------------------------------------------------------------------------------------
SELECT fname, lname, goal.daily_calorie_intake, diet_options.* FROM diet_options, client --options clients have
INNER JOIN client_info ON client_info.clientid=client.clientid
INNER JOIN goal ON client_info.clientid=goal.clientid
WHERE diet_options.calories_per_day>goal.daily_calorie_intake-200 AND 
diet_options.calories_per_day<goal.daily_calorie_intake+200 AND
diet_options.vegeterian=client_info.vegeterian
ORDER BY fname, lname;
---------------------------------------------------------------------------------------------------------
SELECT fname, lname, goal.daily_calorie_intake, COUNT(diet_options.*) FROM diet_options, client --how many options clients have
INNER JOIN client_info ON client_info.clientid=client.clientid
INNER JOIN goal ON client_info.clientid=goal.clientid
WHERE diet_options.calories_per_day > goal.daily_calorie_intake-200 AND 
diet_options.calories_per_day < goal.daily_calorie_intake+200 AND
diet_options.vegeterian=client_info.vegeterian
GROUP BY fname, lname, goal.daily_calorie_intake
ORDER BY fname, lname;
---------------------------------------------------------------------------------------------------------
SELECT calories_per_day, diet_options.name, vegeterian, products.name, recipes.description FROM diet_options --diet options info
INNER JOIN diet_plan_products ON diet_plan_products.diet_planid=diet_options.diet_planid
INNER JOIN diet_plan_recipes ON  diet_plan_recipes.diet_planid=diet_options.diet_planid
INNER JOIN products ON products.productid= diet_plan_products.productid
INNER JOIN recipes ON recipes.recipeid= diet_plan_recipes.recipeid
group by diet_options.name,  vegeterian, products.name, recipes.description, calories_per_day
order by calories_per_day;
---------------------------------------------------------------------------------------------------------
SELECT client.clientid, fname, lname, diagnose.description, bmi, weight, goal_weight from client --clients losing weight
inner join client_info on client_info.clientid=client.clientid
inner join diagnose on diagnose.clientid=client.clientid
inner join goal on goal.clientid=client.clientid
where goal.goal_weight<client_info.weight;
---------------------------------------------------------------------------------------------------------
SELECT fname, lname, bmi, height, weight, diagnose.description from client_info --finding clients with lowest bmi
inner join client on client.clientid = client_info.clientid
inner join diagnose on diagnose.clientid=client_info.clientid
where bmi= (select min(bmi) from client_info);
---------------------------------------------------------------------------------------------------------
SELECT fname, lname, weight from client  --finding clients with highest and lowest weight
inner join client_info on client.clientid=client_info.clientid 
where weight = (select min(weight) from client_info) or weight= (select max(weight) from client_info);